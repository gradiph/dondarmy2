<div class="bg-warning" style="padding:5px 5px; font-size:small">
    <center>
        Admin Donor Darah GKI Maulana Yusuf Bandung
        <br />
        Version 2.0 | 2016
    </center>
</div>
