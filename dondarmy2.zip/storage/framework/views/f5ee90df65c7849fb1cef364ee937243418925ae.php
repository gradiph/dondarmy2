<table class="table table-bordered table-striped table-hover text-center">
    <thead>
        <td>#</td>
        <td>Nama</td>
        <td>Gol. Darah</td>
        <td>Panggil</td>
        <td>Terima</td>
    </thead>
    <tbody>
        <?php foreach($details as $detail): ?>
            <tr>
                <td><?php echo e($detail->antrian); ?></td>
                <td class="text-left"><?php echo e($detail->donor->nama); ?></td>
                <td><?php echo e($detail->donor->golDarah->nama); ?></td>
                <td><button id="btnPanggil" onclick="ajaxLoad('<?php echo e(url('proses-donor/panggil?detail_id='.$detail->id)); ?>','antrian')" class="btn btn-xs <?php echo e(($detail->panggil == 'Belum') ? 'btn-warning' : 'btn-info'); ?>"><i class="glyphicon <?php echo e(($detail->panggil == 'Belum') ? 'glyphicon-bullhorn' : 'glyphicon-ok'); ?>"></i> <?php echo e($detail->panggil); ?></button></td>
                <td><button id="btnTerima" onclick="ajaxLoad('<?php echo e(url('proses-donor/terima?detail_id='.$detail->id)); ?>','antrian')" class="btn btn-xs <?php echo e(($detail->terima == 'Tidak') ? 'btn-warning' : 'btn-info'); ?>"><i class="glyphicon <?php echo e(($detail->terima == 'Tidak') ? 'glyphicon-remove' : 'glyphicon-ok'); ?>"></i> <?php echo e($detail->terima); ?></button></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>