<?php $__env->startSection('title'); ?> Hapus Donor | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php
$golDarah = [];
foreach($golDarahs as $data)
{
    $golDarah += [$data->id => $data->nama];
}
$pekerjaan = [];
foreach($pekerjaans as $data)
{
    $pekerjaan += [$data->id => $data->nama];
}
?>
<meta name="_token" content="<?php echo csrf_token(); ?>" />
<div class="container">
    <div class="row">
        <div class="col-lg-9">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Hapus Donor
                </div>
                <div class="panel-body">
                    <?php echo e(Form::open(['url'=>url('donor/hapus'),'method'=>'post','id'=>'frmDonor','class'=>'form-horizontal'])); ?>

                        <?php echo e(Form::hidden('id',$donor->id)); ?>

                        <?php if(count($errors) > 0): ?>
                            <div id='error' class="alert alert-danger">
                                <?php foreach($errors->all() as $error): ?>
                                    <p><strong><?php echo e($error); ?></strong></p>
                                <?php endforeach; ?>
                                <p><i>Klik untuk menutup</i></p>
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <?php echo e(Form::label('no_register','* No. Register',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::number('no_register',$donor->no_register,['class'=>'form-control','placeholder'=>'Masukkan No. Register','required','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('nama','* Nama',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::text('nama',$donor->nama,['class'=>'form-control','placeholder'=>'Masukkan Nama','required','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('gol_darah_id','Gol. Darah',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::select('gol_darah_id',$golDarah,$donor->gol_darah_id,['class'=>'form-control','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('kelamin','* Jenis Kelamin',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <label class="radio-inline"><?php echo e(($donor->kelamin == 'Pria') ? Form::radio('kelamin','Pria',true) : Form::radio('kelamin','Pria',false)); ?> Pria</label>
                                <label class="radio-inline"><?php echo e(($donor->kelamin == 'Wanita') ? Form::radio('kelamin','Wanita',true) : Form::radio('kelamin','Wanita',false)); ?> Wanita</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('tempat_lahir','* Tempat, Tanggal Lahir',['class'=>'col-sm-4 col-xs-12 control-label'])); ?>

                            <div class="col-sm-5 col-xs-6">
                                <?php echo e(Form::text('tempat_lahir',$donor->tempat_lahir,['class'=>'form-control','placeholder'=>'Masukkan Kota Lahir','required','readonly'])); ?>

                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <?php echo e(Form::date('tgl_lahir',$donor->tgl_lahir,['id'=>'tgl_lahir','class'=>'form-control','placeholder'=>'Klik Pilih Tanggal','required','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('telp','* Telepon',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::number('telp',$donor->telp,['class'=>'form-control','placeholder'=>'Masukkan No. Telepon','required','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('alamat','Alamat',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::text('alamat',$donor->alamat,['class'=>'form-control','placeholder'=>'Masukkan Alamat','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('rt','RT / RW',['class'=>'col-sm-4 col-xs-12 control-label'])); ?>

                            <div class="col-sm-3 col-xs-6">
                                <?php echo e(Form::number('rt',$donor->rt,['class'=>'form-control','placeholder'=>'Masukkan RT','readonly'])); ?>

                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <?php echo e(Form::number('rw',$donor->rw,['id'=>'rw','class'=>'form-control','placeholder'=>'Masukkan RW','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('kelurahan','Kelurahan',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::text('kelurahan',$donor->kelurahan,['class'=>'form-control','placeholder'=>'Masukkan Kelurahan','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('kecamatan','Kecamatan',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::text('kecamatan',$donor->kecamatan,['class'=>'form-control','placeholder'=>'Masukkan Kecamatan','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('kode_pos','Kode Pos',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-4">
                                <?php echo e(Form::number('kode_pos',$donor->kode_pos,['class'=>'form-control','placeholder'=>'Masukkan Kode Pos','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('pekerjaan_id','* Pekerjaan',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::select('pekerjaan_id',$pekerjaan,$donor->pekerjaan_id,['class'=>'form-control','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('penghargaan','Penghargaan',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::select('penghargaan',['10'=>'10x','25'=>'25x','50'=>'50x','75'=>'75x','100'=>'100x'],$donor->penghargaan,['class'=>'form-control','placeholder'=>'Masukkan Penghargaan','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('total_donor','Total Donor',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::number('total_donor',$donor->total_donor,['class'=>'form-control','placeholder'=>'Masukkan Total Donor','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('donor_terakhir','Donor Terakhir',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::date('donor_terakhir',$donor->donor_terakhir,['class'=>'form-control','placeholder'=>'Klik Pilih Tanggal','readonly'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-4 col-sm-2">
                                <?php echo e(Form::submit('Hapus',['class'=>'btn btn-primary btn-block'])); ?>

                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo e(url('donor')); ?>" class="btn btn-info btn-block">Batal</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        $("#tgl_lahir").datepicker({
            dateFormat: "yy-mm-dd",
            changeMonth: true,
            changeYear: true,
            showAnim: "drop",
            showOptions: {direction: "up"}
        });
        $("#donor_terakhir").datepicker({
            dateFormat: "yy-mm-dd",
            changeMonth: true,
            changeYear: true,
            showAnim: "drop",
            showOptions: {direction: "up"}
        });
        $("#error").click(function(){
            $(this).hide('slow');
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>