<?php $__env->startSection('title'); ?> List Kegiatan | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<meta name="_token" content="<?php echo csrf_token(); ?>" />
<div class="container">
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
            <p><strong><?php echo e(Session::get('message')); ?></strong></p>
            <p><i>Klik untuk menutup</i></p>
        </div>
    <?php endif; ?>
    <h2>
        List Kegiatan
        <div class="pull-right">
            <a href="<?php echo e(url('kegiatan/tambah')); ?>" id="btnTambah" class="btn btn-lg btn-primary"><i class="glyphicon glyphicon-plus-sign"></i> Tambah Data</a>
        </div>
    </h2>
    <hr>
    <div id="data"></div>
    <hr>
</div>

<script>
$(document).ready(function(){
    ajaxLoad("<?php echo e(url('kegiatan/list')); ?>",'data');
    $(".alert").click(function(){
        $(this).hide('slow');
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>