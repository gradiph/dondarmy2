<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover text-center">
        <thead>
            <td>
                No
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('kegiatan/list?field=tgl&sort=<?php echo e(Session::get("kegiatan_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Tanggal
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('kegiatan_field')=='tgl'?(Session::get('kegiatan_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('kegiatan/list?field=tempat&sort=<?php echo e(Session::get("kegiatan_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Tempat
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('kegiatan_field')=='tempat'?(Session::get('kegiatan_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('kegiatan/list?field=target_labu&sort=<?php echo e(Session::get("kegiatan_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Target Labu
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('kegiatan_field')=='target_labu'?(Session::get('kegiatan_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('kegiatan/list?field=hasil_labu&sort=<?php echo e(Session::get("kegiatan_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Hasil Labu
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('kegiatan_field')=='hasil_labu'?(Session::get('kegiatan_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('kegiatan/list?field=laporan&sort=<?php echo e(Session::get("kegiatan_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Laporan
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('kegiatan_field')=='laporan'?(Session::get('kegiatan_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>Aksi</td>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php foreach($kegiatans as $kegiatan): ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($kegiatan->tgl); ?></td>
                    <td><?php echo e($kegiatan->tempat); ?></td>
                    <td><?php echo e($kegiatan->target_labu); ?></td>
                    <td><?php echo e($kegiatan->hasil_labu); ?></td>
                    <td><a href="#download" onclick="javascript:ajaxLoad('<?php echo e(url('kegiatan/downloadlaporan?id='.$kegiatan->id)); ?>')" class="link"><?php echo e($kegiatan->path_laporan); ?></a></td>
                    <td>
                        <a href="<?php echo e(url('kegiatan/ubah?id='.$kegiatan->id)); ?>" title="Ubah Data" class="btn btn-xs btn-warning"><i class="glyphicon glyphicon-edit"></i> Ubah</a>
                        <a href="<?php echo e(url('kegiatan/hapus?id='.$kegiatan->id)); ?>" title="Hapus Data" class="btn btn-xs btn-danger"><i class="glyphicon glyphicon-trash"></i> Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <p>
        Total Data : <?php echo e($total); ?>

        <div class="pull-right"><?php echo str_replace('/?','?',$kegiatans->render()); ?></div>
    </p>
</div>
<script>
    $('.pagination a').on('click', function (event) {
        event.preventDefault();
        ajaxLoad($(this).attr('href'),'data');
    });
</script>
