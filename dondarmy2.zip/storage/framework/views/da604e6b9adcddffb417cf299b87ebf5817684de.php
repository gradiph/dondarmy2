<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover text-center">
        <thead>
            <td>
                No
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('user/list?field=nama&sort=<?php echo e(Session::get("user_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Nama
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('user_field')=='nama'?(Session::get('user_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('user/list?field=username&sort=<?php echo e(Session::get("user_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Username
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('user_field')=='username'?(Session::get('user_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('user/list?field=role&sort=<?php echo e(Session::get("user_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Role
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('user_field')=='role'?(Session::get('user_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>Aksi</td>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php foreach($users as $user): ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($user->nama); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->role); ?></td>
                    <td>
                        <a href="<?php echo e(url('user/ubah?id='.$user->id)); ?>" title="Ubah Data" class="btn btn-xs btn-warning"><i class="glyphicon glyphicon-edit"></i> Ubah</a>
                        <a href="<?php echo e(url('user/hapus?id='.$user->id)); ?>" title="Hapus Data" class="btn btn-xs btn-danger"><i class="glyphicon glyphicon-trash"></i> Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <p>
        Total Data : <?php echo e($total); ?>

        <div class="pull-right"><?php echo str_replace('/?','?',$users->render()); ?></div>
    </p>
</div>
<script>
    $('.pagination a').on('click', function (event) {
        event.preventDefault();
        ajaxLoad($(this).attr('href'),'data');
    });
</script>
