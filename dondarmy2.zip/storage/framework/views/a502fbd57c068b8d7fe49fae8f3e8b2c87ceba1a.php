<?php $__env->startSection('title'); ?> List Donor | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<meta name="_token" content="<?php echo csrf_token(); ?>" />
<div class="container">
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
            <p><strong><?php echo e(Session::get('message')); ?></strong></p>
            <p><i>Klik untuk menutup</i></p>
        </div>
    <?php endif; ?>
    <h2>
        List Donor
        <div class="pull-right">
            <a href="<?php echo e(url('donor/tambah')); ?>" id="btnTambah" class="btn btn-lg btn-primary"><i class="glyphicon glyphicon-plus-sign"></i> Tambah Data</a>
        </div>
    </h2>
    <hr>
    <div id="new"></div>
    <div class="row">
        <div class="col-lg-4 form-group">
            <div class="input-group">
                <input class="form-control" id="search" value="<?php echo e(Session::get('donor_search')); ?>"
                       onkeyup="if ((event.keyCode >= 65 && event.keyCode <= 90) || event.keyCode == 13 || event.keyCode == 8 || event.keyCode == 46) ajaxLoad('<?php echo e(url('donor/list')); ?>?ok=1&search='+this.value,'data')"
                       placeholder="Cari Nama ..."
                       type="text"
                       autofocus>
                <div class="input-group-btn">
                    <button type="button" class="btn btn-default"
                            onclick="ajaxLoad('<?php echo e(url('donor/list')); ?>?ok=1&search='+$('#search').val(),'data')"><i
                                class="glyphicon glyphicon-search"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="col-lg-3 form-group">
            <div class="input-group">
                <select class="form-control" id="search-gol" onchange="ajaxLoad('<?php echo e(url('donor/list')); ?>?ok-gol=1&search-gol='+this.value,'data')">
                    <option value="">Semua Gol. Darah</option>
                    <option value="1">A</option>
                    <option value="2">A+</option>
                    <option value="3">A-</option>
                    <option value="4">AB</option>
                    <option value="5">AB+</option>
                    <option value="6">AB-</option>
                    <option value="7">B</option>
                    <option value="8">B+</option>
                    <option value="9">B-</option>
                    <option value="10">O</option>
                    <option value="11">O+</option>
                    <option value="12">O-</option>
                    <option value="13">-</option>
                </select>
            </div>
        </div>
    </div>
    <div id="data"></div>
    <hr>
</div>

<script>
$(document).ready(function(){
    ajaxLoad("<?php echo e(url('donor/list')); ?>",'data');
    $(".alert").click(function(){
        $(this).hide('slow');
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>