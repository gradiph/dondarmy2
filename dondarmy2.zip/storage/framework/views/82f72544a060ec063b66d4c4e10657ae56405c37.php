<nav class="navbar navbar-default">
	<div class="container">
    	<div class="navbar-header">
        	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            	<span class="icon-bar"></span>
            	<span class="icon-bar"></span>
            	<span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(URL('/')); ?>">DonDar MY</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
        	<ul class="nav navbar-nav">
            	<li><a href="<?php echo e(URL('/')); ?>">Home</a></li>
                <li><a href="<?php echo e(URL('donor')); ?>">Donor</a></li>
                <li><a href="<?php echo e(URL('kegiatan')); ?>">Kegiatan</a></li>
                <li><a href="<?php echo e(URL('proses-donor')); ?>">Proses Donor</a></li>
                <li><a href="<?php echo e(URL('user')); ?>">User</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href=""><span class="glyphicon glyphicon-user"></span> <?php echo e(Auth::user() ? Auth::user()->nama : ''); ?></a></li>
            	<li><a href="<?php echo e(URL('logout')); ?>">Keluar</a></li>
            </ul>
        </div>
    </div>
</nav>
