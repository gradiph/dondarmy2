<?php $__env->startSection('title'); ?> Proses Donor | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php
$kegiatan = [];
$kegiatan += ['0' => 'Pilih Kegiatan ...'];
foreach ($kegiatans as $data)
{
    $kegiatan += [$data->id => $data->tgl];
}
?>
<meta name="_token" content="<?php echo csrf_token(); ?>" />
<div class="container">
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
            <p><strong><?php echo e(Session::get('message')); ?></strong></p>
            <p><i>Klik untuk menutup</i></p>
        </div>
    <?php endif; ?>
    <h2>
        Proses Donor <span id="tgl"></span>
    </h2>
    <hr>
    <div class="row">
        <div class="col-lg-6">
            <div class="row">
                <div class="col-lg-4" style="line-height:33px; letter-spacing:1px; text-align:right;">Tanggal Kegiatan</div>
                <div class="col-lg-4 form-group">
                    <?php echo e(Form::select(
                        'proses_kegiatan',
                        $kegiatan,
                        Session::get('proses_kegiatan'),
                        [
                            'class' => 'form-control',
                            'id' => 'proses_kegiatan'
                        ]
                    )); ?>

                </div>
<!--
                <div class="col-lg-1">
                    <button id="btnRefresh" class="btn btn-danger">Refresh List</button>
                </div>
-->
            </div>
            <div class="col-lg-12" id="antrian"></div>
        </div>
        <div class="col-lg-6 form-group">
            <div class="col-lg-8 form-group">
                <div class="input-group">
                    <input class="form-control" id="search" value="<?php echo e(Session::get('proses_search')); ?>"
                           onkeyup="if ((event.keyCode >= 48 && event.keyCode <= 90) || event.keyCode == 13 || event.keyCode == 8 || event.keyCode == 46) ajaxLoad('<?php echo e(url('proses-donor/listdonor')); ?>?ok=1&search='+this.value,'donor')"
                           placeholder="Cari Nama ..."
                           type="text"
                           autofocus>
                    <div class="input-group-btn">
                        <button type="button" class="btn btn-default"
                                onclick="ajaxLoad('<?php echo e(url('proses-donor/listdonor')); ?>?ok=1&search='+$('#search').val(),'donor')"><i
                                    class="glyphicon glyphicon-search"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <a href="<?php echo e(url('proses-donor/tambahdonor')); ?>" class="btn btn-block btn-danger"><i class="glyphicon glyphicon-plus"></i> Tambah Donor</a>
            </div>
            <div class="col-lg-12" id="donor"></div>
        </div>
    </div>
    <div class="row">
    </div>
    <hr>
</div>

<script>
$(document).ready(function(){
    ajaxLoad("<?php echo e(url('proses-donor/listdonor')); ?>",'donor');
    ajaxLoad("<?php echo e(url('proses-donor/listantrian')); ?>",'antrian');
    $(".alert").click(function(){
        $(this).hide('slow');
    });
    $("#proses_kegiatan").change(function(){
        ajaxLoad("<?php echo e(url('proses-donor/listantrian?id=')); ?>" + $(this).val(),'antrian');
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>