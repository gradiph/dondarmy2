<?php $__env->startSection('title'); ?> Tambah User | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<meta name="_token" content="<?php echo csrf_token(); ?>" />
<div class="container">
    <div class="row">
        <div class="col-lg-9">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Data User Baru
                </div>
                <div class="panel-body">
                    <?php echo e(Form::open(['url'=>url('user/tambah'),'method'=>'post','id'=>'frmUser','class'=>'form-horizontal'])); ?>

                        <?php if(count($errors) > 0): ?>
                            <div id='error' class="alert alert-danger">
                                <?php foreach($errors->all() as $error): ?>
                                    <p><strong><?php echo e($error); ?></strong></p>
                                <?php endforeach; ?>
                                <p><i>Klik untuk menutup</i></p>
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <?php echo e(Form::label('nama','* Nama',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::text('nama',old('nama'),['class'=>'form-control','placeholder'=>'Masukkan Nama User ...','required'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('username','* Username',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::text('username',old('username'),['class'=>'form-control','placeholder'=>'Masukkan Username User ...','required'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('password','* Password',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::password('password',['class'=>'form-control','required'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('role','* Role',['class'=>'col-sm-4 control-label'])); ?>

                            <div class="col-sm-8">
                                <?php echo e(Form::select('role',['Panitia'=>'Panitia','Admin'=>'Admin','SuperAdmin'=>'Super Admin'],old('role'),['class'=>'form-control','required'])); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-4 col-sm-2">
                                <?php echo e(Form::submit('Simpan',['class'=>'btn btn-primary btn-block','id'=>'btnSimpan'])); ?>

                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo e(url('user')); ?>" class="btn btn-info btn-block">Batal</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        $("#error").click(function(){
            $(this).hide('slow');
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>