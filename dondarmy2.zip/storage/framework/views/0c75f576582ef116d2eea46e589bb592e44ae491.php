<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover text-center">
        <tbody>
            <?php foreach($donors as $donor): ?>
                <tr>
                    <td class="text-left"><?php echo e($donor->nama); ?></td>
                    <td><?php echo e($donor->golDarah->nama); ?></td>
                    <td><?php echo e($donor->tgl_lahir); ?></td>
                    <td>
                        <button id="btnPilih" value="<?php echo e($donor->id); ?>" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-check"></i> Pilih</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<script>
    $(document).ready(function(){
        $("#btnPilih").click(function(){
            var donor_id = $("#btnPilih").val();
            var win = window.open('<?php echo e(url('proses-donor/print?donor_id=')); ?>' + donor_id, '_blank');
            if (win) {
                //Browser has allowed it to be opened
                win.focus();
                $.ajax({
                    method: "GET",
                    url: "<?php echo e(url('proses-donor/pilih')); ?>",
                    cache: false,
                    data: {
                        donor_id: donor_id
                    }
                })
                .done(function(){
                    ajaxLoad("<?php echo e(url('proses-donor/listdonor')); ?>",'donor');
                    ajaxLoad("<?php echo e(url('proses-donor/listantrian')); ?>",'antrian');
                })
                .fail(function(){
                    alert('Error: "Pilih Donor"');
                });
            } 
            else {
                //Browser has blocked it
                alert('Please allow popups for this website');
            }
        });
    });
</script>